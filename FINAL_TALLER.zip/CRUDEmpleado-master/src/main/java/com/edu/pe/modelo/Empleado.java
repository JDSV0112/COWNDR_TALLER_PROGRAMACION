package com.edu.pe.modelo;

public class Empleado {
    private int id;
    private String raza;
    private String edad;
    private String sexo;
    private String historialMedico;  // Cambiar a camelCase

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getHistorialMedico() {  // Cambiar el getter a camelCase
        return historialMedico;
    }

    public void setHistorialMedico(String historialMedico) {  // Cambiar el setter a camelCase
        this.historialMedico = historialMedico;
    }
}
