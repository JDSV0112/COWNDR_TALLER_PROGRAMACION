package com.edu.pe.modelo.dao;

import com.edu.pe.config.Conexion;
import com.edu.pe.modelo.Empleado;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class EmpleadoDAO {
    
    private Connection cn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    
    public ArrayList<Empleado> ListarTodos() {
        ArrayList<Empleado> lista = new ArrayList<>();
        
        try {
            cn = Conexion.getConnection();
            String sql = "select * from bovinos";
            ps = cn.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while (rs.next()) {
                Empleado obj = new Empleado();
                obj.setId(rs.getInt("id"));
                obj.setRaza(rs.getString("raza"));
                obj.setEdad(rs.getString("edad"));
                obj.setSexo(rs.getString("sexo"));
                obj.setHistorialMedico(rs.getString("historialMedico")); // Cambié a historialMedico
                lista.add(obj);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                }
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            } catch (Exception ex) {
                
            }
        }
        
        return lista;
    }
    
    public int registrar(Empleado obj) {
        int result = 0;
        
        try {
            cn = Conexion.getConnection();
            String sql = "INSERT INTO bovinos(raza,edad,sexo,historialMedico) "
                    + "VALUES (?,?,?,?)";
            ps = cn.prepareStatement(sql);
            ps.setString(1, obj.getRaza());
            ps.setString(2, obj.getEdad());
            ps.setString(3, obj.getSexo());
            ps.setString(4, obj.getHistorialMedico()); // Cambié a historialMedico
            
            result = ps.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                }
                if (ps != null) {
                    ps.close();
                }
            } catch (Exception ex) {
                
            }
        }
        
        return result;
    }
    
    public int editar(Empleado obj) {
        int result = 0;
        
        try {
            cn = Conexion.getConnection();
            String sql = "UPDATE bovinos SET raza=?, edad=?,sexo=?,historialMedico=?"
                    + " WHERE id=?";
            ps = cn.prepareStatement(sql);
            ps.setString(1, obj.getRaza());
            ps.setString(2, obj.getEdad());
            ps.setString(3, obj.getSexo());
            ps.setString(4, obj.getHistorialMedico()); // Cambié a historialMedico
            ps.setInt(5, obj.getId());
            result = ps.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                }
                if (ps != null) {
                    ps.close();
                }
            } catch (Exception ex) {
                
            }
        }
        
        return result;
    }
    
    public int eliminar(int id) {
        int result = 0;
        
        try {
            cn = Conexion.getConnection();
            String sql = "DELETE FROM bovinos WHERE id = ?";
            ps = cn.prepareStatement(sql);
            ps.setInt(1, id);
            result = ps.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                }
                if (ps != null) {
                    ps.close();
                }
            } catch (Exception ex) {
                
            }
        }
        
        return result;
    }
    
    public Empleado buscarPorId(int id) {
        Empleado obj = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "select * from bovinos where id = ?";
            ps = cn.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                obj = new Empleado();
                obj.setId(rs.getInt("id"));
                obj.setRaza(rs.getString("raza"));
                obj.setEdad(rs.getString("edad"));
                obj.setSexo(rs.getString("sexo"));
                obj.setHistorialMedico(rs.getString("historialMedico")); // Cambié a historialMedico
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                }
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            } catch (Exception ex) {
                
            }
        }
        
        return obj;
    }
}
